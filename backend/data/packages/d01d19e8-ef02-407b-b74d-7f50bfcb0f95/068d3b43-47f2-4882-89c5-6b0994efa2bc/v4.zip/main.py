def saudacao(nome: str) -> str:
    return f"Olá, {nome}! O Python está funcionando."


def soma(a: float, b: float) -> float:
    return a + b


def main():
    print(saudacao("mundo"))
    print(f"2 + 3 = {soma(2, 3)}")


if __name__ == "__main__":
    main()
